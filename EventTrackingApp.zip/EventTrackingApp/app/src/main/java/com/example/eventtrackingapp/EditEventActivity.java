package com.example.eventtrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {
    private EditText titleField, descriptionField;
    private DatePicker datePicker;
    private TimePicker timePicker;
    private Button updateButton;
    private AppDatabase db;
    private EventEntity event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event); // dedicated edit layout

        titleField = findViewById(R.id.eventTitle);
        descriptionField = findViewById(R.id.eventDescription);
        datePicker = findViewById(R.id.eventDate);
        timePicker = findViewById(R.id.eventTime);
        updateButton = findViewById(R.id.updateEventButton);

        db = AppDatabase.getDatabase(this);

        int eventId = getIntent().getIntExtra("event_id", -1);
        event = db.eventDao().getEventById(eventId);

        if (event == null) {
            Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Pre-fill fields
        titleField.setText(event.title);
        descriptionField.setText(event.description);

        // Parse "MM/DD/YYYY HH:mm" back into pickers
        try {
            String[] parts = event.dateTime.split(" ");
            String[] dateParts = parts[0].split("/");
            String[] timeParts = parts[1].split(":");

            int month = Integer.parseInt(dateParts[0]) - 1; // DatePicker months are 0-based
            int day = Integer.parseInt(dateParts[1]);
            int year = Integer.parseInt(dateParts[2]);
            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);

            datePicker.updateDate(year, month, day);
            timePicker.setHour(hour);
            timePicker.setMinute(minute);
        } catch (Exception e) {
            // leave defaults if parsing fails
        }

        updateButton.setOnClickListener(v -> {
            event.title = titleField.getText().toString().trim();
            event.description = descriptionField.getText().toString().trim();

            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1;
            int year = datePicker.getYear();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            event.dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;

            db.eventDao().updateEvent(event);
            Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
            finish(); // return to EventGridActivity
        });
    }
}
