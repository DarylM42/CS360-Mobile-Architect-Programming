package com.example.eventtrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {
    private EditText titleField, descriptionField;
    private DatePicker datePicker;
    private TimePicker timePicker;
    private Button saveButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Match IDs from your XML
        titleField = findViewById(R.id.eventTitle);
        descriptionField = findViewById(R.id.eventDescription);
        datePicker = findViewById(R.id.eventDate);
        timePicker = findViewById(R.id.eventTime);
        saveButton = findViewById(R.id.saveEventButton);

        db = AppDatabase.getDatabase(this);

        saveButton.setOnClickListener(v -> {
            String title = titleField.getText().toString().trim();
            String description = descriptionField.getText().toString().trim();

            // Build a date/time string from DatePicker and TimePicker
            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1; // months are 0-based
            int year = datePicker.getYear();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            String dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;

            if (title.isEmpty()) {
                Toast.makeText(this, "Enter a title", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insert new event into database
            db.eventDao().insertEvent(new EventEntity(title, description, dateTime));

            Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();

            // Close activity and return to EventGridActivity
            finish();
        });
    }
}
