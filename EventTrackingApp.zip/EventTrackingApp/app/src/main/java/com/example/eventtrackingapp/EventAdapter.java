package com.example.eventtrackingapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.snackbar.Snackbar;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
    private List<EventEntity> events;
    private AppDatabase db;

    public EventAdapter(List<EventEntity> events, AppDatabase db) {
        this.events = events;
        this.db = db;
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(v);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        EventEntity event = events.get(position);
        holder.title.setText(event.title != null ? event.title : "");
        holder.description.setText(event.description != null ? event.description : "");
        holder.date.setText(event.dateTime != null ? event.dateTime : "");

        // Delete with confirmation + Undo
        holder.deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(v.getContext())
                    .setTitle("Delete Event")
                    .setMessage("Are you sure you want to delete this event?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        EventEntity deletedEvent = event;
                        int deletedPosition = position;

                        db.eventDao().deleteEvent(deletedEvent);
                        events.remove(deletedPosition);
                        notifyItemRemoved(deletedPosition);

                        Snackbar.make(v, "Event deleted", Snackbar.LENGTH_LONG)
                                .setAction("Undo", undoView -> {
                                    db.eventDao().insertEvent(deletedEvent);
                                    events.add(deletedPosition, deletedEvent);
                                    notifyItemInserted(deletedPosition);
                                })
                                .show();
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        // Click to edit
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), EditEventActivity.class);
            intent.putExtra("event_id", event.id);
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView title, description, date;
        Button deleteButton;

        public EventViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.eventTitle);
            description = itemView.findViewById(R.id.eventDescription);
            date = itemView.findViewById(R.id.eventDate);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
