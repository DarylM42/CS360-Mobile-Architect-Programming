package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventGridActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private AppDatabase db;
    private Button addEventButton, smsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        recyclerView = findViewById(R.id.recyclerView);
        addEventButton = findViewById(R.id.addEventButton);
        smsButton = findViewById(R.id.smsButton); // ✅ new button

        db = AppDatabase.getDatabase(this);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        loadEvents();

        // Navigate to Add Event screen
        addEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventGridActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        // Navigate to SMS screen
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventGridActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload events whenever returning from Add/Edit
        loadEvents();
    }

    private void loadEvents() {
        List<EventEntity> events = db.eventDao().getAllEvents();
        adapter = new EventAdapter(events, db);
        recyclerView.setAdapter(adapter);
    }
}
